import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modelcontent',
  templateUrl: './modelcontent.component.html',
  styleUrls: ['./modelcontent.component.scss']
})
export class ModelcontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
