import { DatatimePipe } from './datatime.pipe';

describe('DatatimePipe', () => {
  it('create an instance', () => {
    const pipe = new DatatimePipe();
    expect(pipe).toBeTruthy();
  });
});
